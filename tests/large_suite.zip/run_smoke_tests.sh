#!/usr/bin/env sh
set -eu
BIN="${1:-./build/patterndetect}"
expr_out="$($BIN --expr 'add(multiply(2,3),4)')"
[ "$expr_out" = "10" ] || { echo "expression test failed: $expr_out"; exit 1; }
$BIN --validate-only --config examples/patterndetect.conf >/tmp/patterndetect_validate.out
$BIN --config examples/patterndetect.conf --log examples/sample.log >/tmp/patterndetect_scan.out
grep -q "REPORT: Initial problem1 found" /tmp/patterndetect_scan.out
grep -q "REPORT: Problem1 issue marker 2 observed" /tmp/patterndetect_scan.out
echo "PatternDetect smoke tests passed"
