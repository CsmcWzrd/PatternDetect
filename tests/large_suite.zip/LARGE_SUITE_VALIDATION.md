# PatternDetect large suite validation

- Binary: `/mnt/data/PatternDetect/build/patterndetect`
- Suite: `/mnt/data/PatternDetect/tests/large_suite`
- Cases executed: 1000 of 1000
- Parallel jobs: 8
- Expression tests executed: 5
- Failures: 0
- Elapsed seconds: 8.153

## Coverage from manifest

- pattern_count_range: [5, 10]
- chain_depth_range: [1, 10]
- fanout_range: [0, 9]
- pattern_step_range: [1, 10]
- rotation_count_range: [0, 10]
- log_line_count_range: [300, 10000]

## Result

PASSED
